"""
MCP Framework - Monitoring Routes
Competitor tracking, rank checking, content queue management
"""
from flask import Blueprint, request, jsonify, current_app
from datetime import datetime, timedelta
import json
import logging
import os

from app.routes.auth import token_required, admin_required
from app.utils import safe_int
from app.database import db
from app.models.db_models import (
    DBClient, DBCompetitor, DBCompetitorPage, DBRankHistory,
    DBContentQueue, DBAlert, DBBlogPost, ContentStatus
)
from app.services.competitor_monitoring_service import competitor_monitoring_service
from app.services.seo_scoring_engine import seo_scoring_engine
from app.services.rank_tracking_service import rank_tracking_service
from app.services.ai_service import AIService

logger = logging.getLogger(__name__)

monitoring_bp = Blueprint('monitoring', __name__)
ai_service = AIService()


# ==========================================
# SEMRUSH API TEST
# ==========================================

@monitoring_bp.route('/semrush-test', methods=['GET'])
@token_required
def test_semrush_api(current_user):
    """
    Test SEMrush API connectivity and key validity
    
    GET /api/monitoring/semrush-test
    """
    import requests
    
    api_key = os.environ.get('SEMRUSH_API_KEY', '')
    
    # Sanitize
    api_key_clean = api_key.strip().strip('"').strip("'").strip() if api_key else ''
    
    result = {
        'key_length': len(api_key),
        'key_clean_length': len(api_key_clean),
        'key_prefix': api_key_clean[:4] + '...' if len(api_key_clean) > 4 else 'too_short',
        'key_suffix': '...' + api_key_clean[-4:] if len(api_key_clean) > 4 else 'too_short',
        'has_whitespace': api_key != api_key_clean,
        'has_quotes': '"' in api_key or "'" in api_key,
    }
    
    if not api_key_clean:
        result['error'] = 'No API key configured'
        return jsonify(result), 400
    
    # Test with a simple API call (domain overview uses fewer units)
    try:
        test_url = 'https://api.semrush.com/'
        params = {
            'type': 'domain_ranks',
            'key': api_key_clean,
            'domain': 'google.com',
            'database': 'us'
        }
        
        response = requests.get(test_url, params=params, timeout=10)
        
        result['api_status'] = response.status_code
        result['api_response_preview'] = response.text[:200]
        
        if response.status_code == 200 and not response.text.startswith('ERROR'):
            result['success'] = True
            result['message'] = 'SEMrush API is working!'
        else:
            result['success'] = False
            result['error'] = response.text[:500]
            
    except Exception as e:
        result['success'] = False
        result['error'] = str(e)
    
    return jsonify(result)


@monitoring_bp.route('/debug-competitors/<client_id>', methods=['GET'])
@token_required
def debug_competitors(current_user, client_id):
    """
    Debug endpoint to see competitor data
    
    GET /api/monitoring/debug-competitors/{client_id}
    """
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    client = DBClient.query.get(client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    # Raw client.competitors field
    raw_competitors = client.competitors
    
    # Parsed competitors
    parsed_competitors = []
    try:
        if raw_competitors:
            parsed_competitors = json.loads(raw_competitors) if isinstance(raw_competitors, str) else raw_competitors
    except Exception as e:
        parsed_competitors = f"PARSE ERROR: {e}"
    
    # All DBCompetitor entries
    all_db = DBCompetitor.query.filter_by(client_id=client_id).all()
    db_competitors = [{
        'id': c.id,
        'domain': c.domain,
        'name': c.name,
        'is_active': c.is_active
    } for c in all_db]
    
    # Active DBCompetitor entries
    active_db = [c for c in db_competitors if c['is_active']]
    
    return jsonify({
        'client_id': client_id,
        'raw_competitors_field': raw_competitors,
        'parsed_competitors': parsed_competitors,
        'db_competitors_all': db_competitors,
        'db_competitors_active': active_db,
        'counts': {
            'in_settings': len(parsed_competitors) if isinstance(parsed_competitors, list) else 0,
            'in_db_total': len(db_competitors),
            'in_db_active': len(active_db)
        }
    })


@monitoring_bp.route('/cleanup-competitors/<client_id>', methods=['POST'])
@token_required
def cleanup_duplicate_competitors(current_user, client_id):
    """
    Remove duplicate competitors for a client
    
    POST /api/monitoring/cleanup-competitors/{client_id}
    """
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    def normalize_domain(d):
        if not d:
            return ''
        return d.lower().replace('www.', '').replace('https://', '').replace('http://', '').strip('/').strip()
    
    # Get all competitors for client
    all_comps = DBCompetitor.query.filter_by(client_id=client_id).all()
    
    seen_domains = {}
    duplicates_removed = 0
    
    for comp in all_comps:
        domain = normalize_domain(comp.domain)
        if domain in seen_domains:
            # This is a duplicate - deactivate/delete
            db.session.delete(comp)
            duplicates_removed += 1
        else:
            seen_domains[domain] = comp
    
    try:
        db.session.commit()
        return jsonify({
            'success': True,
            'duplicates_removed': duplicates_removed,
            'remaining': len(seen_domains)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ==========================================
# COMPETITOR MANAGEMENT
# ==========================================

@monitoring_bp.route('/competitors', methods=['GET'])
@token_required
def list_competitors(current_user):
    """List all competitors for a client"""
    client_id = request.args.get('client_id')
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    competitors = DBCompetitor.query.filter_by(
        client_id=client_id,
        is_active=True
    ).all()
    
    return jsonify({
        'client_id': client_id,
        'competitors': [c.to_dict() for c in competitors]
    })


@monitoring_bp.route('/competitors', methods=['POST'])
@token_required
def add_competitor(current_user):
    """
    Add a competitor to monitor
    
    POST /api/monitoring/competitors
    {
        "client_id": "client_abc123",
        "domain": "competitor.com",
        "name": "Main Competitor"
    }
    """
    data = request.get_json(silent=True) or {}
    
    client_id = data.get('client_id')
    domain = data.get('domain', '').strip().lower()
    
    # Normalize domain
    domain = domain.replace('https://', '').replace('http://', '').replace('www.', '').strip('/')
    
    if not client_id or not domain:
        return jsonify({'error': 'client_id and domain required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    logger.info(f"=== ADD COMPETITOR START ===")
    logger.info(f"Adding competitor: client={client_id}, domain={domain}")
    
    # Get client
    client = DBClient.query.get(client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    # Get current competitors from client.competitors field
    current_competitors = []
    try:
        if client.competitors:
            current_competitors = json.loads(client.competitors) if isinstance(client.competitors, str) else client.competitors
            if not isinstance(current_competitors, list):
                current_competitors = []
    except Exception as e:
        logger.warning(f"Error parsing competitors: {e}")
        current_competitors = []
    
    logger.info(f"Current competitors before add: {current_competitors}")
    
    # Check if already in list
    normalized_existing = [c.lower().replace('www.', '').replace('https://', '').replace('http://', '').strip('/') 
                          for c in current_competitors if isinstance(c, str)]
    
    if domain in normalized_existing:
        return jsonify({'error': f'Competitor {domain} already exists'}), 400
    
    # Check limit
    if len(current_competitors) >= 10:
        return jsonify({'error': 'Maximum 10 competitors per client'}), 400
    
    # Add to client.competitors field (single source of truth)
    current_competitors.append(domain)
    client.competitors = json.dumps(current_competitors)
    logger.info(f"Updated client.competitors to: {client.competitors}")
    
    # Also create/update DBCompetitor entry
    existing_db = DBCompetitor.query.filter_by(client_id=client_id, domain=domain).first()
    if existing_db:
        existing_db.is_active = True
        existing_db.name = data.get('name', domain)
        competitor = existing_db
        logger.info(f"Reactivated existing DBCompetitor: {existing_db.id}")
    else:
        competitor = DBCompetitor(
            client_id=client_id,
            domain=domain,
            name=data.get('name', domain),
            crawl_frequency=data.get('crawl_frequency', 'daily')
        )
        competitor.next_crawl_at = datetime.utcnow()
        db.session.add(competitor)
        logger.info(f"Created new DBCompetitor")
    
    try:
        db.session.commit()
        logger.info(f"=== ADD COMPETITOR SUCCESS: {domain} ===")
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error committing: {e}")
        return jsonify({'error': 'Database error'}), 500
    
    return jsonify({
        'message': 'Competitor added',
        'competitor': competitor.to_dict(),
        'updated_competitors': current_competitors
    })


@monitoring_bp.route('/competitors/<competitor_id>', methods=['DELETE'])
@token_required
def remove_competitor(current_user, competitor_id):
    """Remove a competitor from monitoring"""
    logger.info(f"=== DELETE COMPETITOR START ===")
    logger.info(f"Delete competitor request: {competitor_id}")
    
    competitor = DBCompetitor.query.get(competitor_id)
    
    if not competitor:
        logger.warning(f"Competitor not found: {competitor_id}")
        return jsonify({'error': 'Competitor not found'}), 404
    
    if not current_user.has_access_to_client(competitor.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    # Get the domain before deleting
    domain_to_remove = competitor.domain.lower().replace('www.', '').strip()
    client_id = competitor.client_id
    
    logger.info(f"Removing domain: {domain_to_remove} from client: {client_id}")
    
    try:
        # Remove from client.competitors field (single source of truth)
        client = DBClient.query.get(client_id)
        if client:
            current_competitors = []
            if client.competitors:
                current_competitors = json.loads(client.competitors) if isinstance(client.competitors, str) else client.competitors
            
            logger.info(f"Current competitors before delete: {current_competitors}")
            
            if isinstance(current_competitors, list):
                # Filter out the domain we're removing
                updated_competitors = [
                    c for c in current_competitors 
                    if isinstance(c, str) and c.lower().replace('www.', '').replace('https://', '').replace('http://', '').strip('/') != domain_to_remove
                ]
                client.competitors = json.dumps(updated_competitors)
                logger.info(f"Updated client.competitors to: {updated_competitors}")
        
        # Delete from DBCompetitor table
        DBCompetitorPage.query.filter_by(competitor_id=competitor_id).delete()
        db.session.delete(competitor)
        
        # Commit ALL changes together
        db.session.commit()
        logger.info(f"=== DELETE COMPETITOR SUCCESS: {domain_to_remove} ===")
        return jsonify({'message': 'Competitor deleted', 'updated_competitors': updated_competitors if 'updated_competitors' in dir() else []})
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting competitor: {e}")
        return jsonify({'error': f'Failed to delete: {str(e)}'}), 500


@monitoring_bp.route('/competitors/<competitor_id>/schedule', methods=['PUT'])
@token_required
def update_competitor_schedule(current_user, competitor_id):
    """
    Update competitor crawl schedule
    
    PUT /api/monitoring/competitors/{competitor_id}/schedule
    {
        "crawl_frequency": "daily|weekly|manual"
    }
    """
    competitor = DBCompetitor.query.get(competitor_id)
    
    if not competitor:
        return jsonify({'error': 'Competitor not found'}), 404
    
    if not current_user.has_access_to_client(competitor.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.get_json(silent=True) or {}
    frequency = data.get('crawl_frequency', 'daily')
    
    if frequency not in ['daily', 'weekly', 'manual']:
        return jsonify({'error': 'Invalid frequency. Use: daily, weekly, or manual'}), 400
    
    competitor.crawl_frequency = frequency
    
    # Update next crawl time
    if frequency == 'daily':
        competitor.next_crawl_at = datetime.utcnow() + timedelta(days=1)
    elif frequency == 'weekly':
        competitor.next_crawl_at = datetime.utcnow() + timedelta(weeks=1)
    else:
        competitor.next_crawl_at = None
    
    db.session.commit()
    
    return jsonify({
        'message': 'Schedule updated',
        'crawl_frequency': frequency,
        'next_crawl_at': competitor.next_crawl_at.isoformat() if competitor.next_crawl_at else None
    })


@monitoring_bp.route('/competitors/<competitor_id>/crawl', methods=['POST'])
@token_required
def crawl_competitor(current_user, competitor_id):
    """
    Manually trigger a crawl of a competitor
    Returns new pages detected
    """
    try:
        competitor = DBCompetitor.query.get(competitor_id)
        
        if not competitor:
            return jsonify({'error': 'Competitor not found'}), 404
        
        if not current_user.has_access_to_client(competitor.client_id):
            return jsonify({'error': 'Access denied'}), 403
        
        # Get known pages
        known_pages = DBCompetitorPage.query.filter_by(
            competitor_id=competitor_id
        ).all()
        
        known_page_data = [{'url': p.url, 'lastmod': None} for p in known_pages]
        
        # Crawl for new content
        new_pages, updated_pages = competitor_monitoring_service.detect_new_content(
            competitor.domain,
            known_page_data,
            competitor.last_crawl_at
        )
        
        # Save new pages - save all discovered pages but only extract content for first 5
        saved_pages = []
        pages_with_content = 0
        max_content_extract = 5  # Only do expensive content fetch for 5 pages
        
        for page_data in new_pages:
            page_url = page_data['url']
            
            # Check if already exists
            existing = DBCompetitorPage.query.filter_by(
                competitor_id=competitor_id, url=page_url
            ).first()
            if existing:
                continue
            
            # For first few pages, do full content extraction
            if pages_with_content < max_content_extract:
                content = competitor_monitoring_service.extract_page_content(page_url)
                if content.get('error'):
                    # Still save the URL even if extraction fails
                    title = page_data.get('title', '')
                    word_count = 0
                else:
                    title = content.get('title', '')
                    word_count = content.get('word_count', 0)
                    if word_count > 0:
                        pages_with_content += 1
            else:
                # For remaining pages, just save URL with title from sitemap
                title = page_data.get('title', '')
                word_count = 0
                content = {}
            
            # Determine page type from URL
            url_lower = page_url.lower()
            
            page = DBCompetitorPage(
                competitor_id=competitor_id,
                client_id=competitor.client_id,
                url=page_url,
                title=title or page_url.split('/')[-1].replace('-', ' ').replace('_', ' ').title(),
                content_hash=content.get('content_hash', ''),
                word_count=word_count,
                h1=content.get('h1', ''),
                meta_description=content.get('meta_description', '')
            )
            
            db.session.add(page)
            saved_pages.append(page)
        
        # Update competitor stats
        competitor.last_crawl_at = datetime.utcnow()
        competitor.next_crawl_at = datetime.utcnow() + timedelta(days=1)
        competitor.known_pages_count = len(known_pages) + len(saved_pages)
        competitor.new_pages_detected += len(saved_pages)
        
        db.session.commit()
        
        # Send alert email if new pages found and alerts enabled
        if len(saved_pages) > 0:
            try:
                from app.services.email_service import email_service
                # Get client for this competitor
                comp_client = DBClient.query.get(competitor.client_id)
                if comp_client:
                    # Check if alerts are enabled (stored in client settings or default to True)
                    integrations = comp_client.get_integrations()
                    alerts_enabled = integrations.get('competitor_alerts', True)
                    
                    if alerts_enabled:
                        # Send to client email and any admin users
                        recipients = set()
                        if comp_client.email:
                            recipients.add(comp_client.email)
                        
                        # Also notify admin users who have access
                        from app.models.db_models import DBUser
                        admins = DBUser.query.filter(DBUser.role.in_(['admin', 'manager']), DBUser.is_active == True).all()
                        for admin in admins:
                            if admin.email and admin.has_access_to_client(comp_client.id):
                                recipients.add(admin.email)
                        
                        page_titles = [p.title or p.url for p in saved_pages[:5]]
                        for recipient in recipients:
                            try:
                                email_service.send_competitor_alert(
                                    to=recipient,
                                    client_name=comp_client.business_name,
                                    competitor_name=competitor.name or competitor.domain,
                                    new_pages=len(saved_pages)
                                )
                                logger.info(f"Sent competitor alert to {recipient}: {competitor.name} has {len(saved_pages)} new pages")
                            except Exception as email_err:
                                logger.warning(f"Failed to send competitor alert to {recipient}: {email_err}")
            except Exception as alert_err:
                logger.warning(f"Could not send competitor alerts: {alert_err}")
        
        return jsonify({
            'competitor': competitor.to_dict(),
            'new_pages_found': len(saved_pages),
            'pages': [p.to_dict() for p in saved_pages]
        })
        
    except Exception as e:
        import traceback
        logger.error(f"Crawl error for competitor {competitor_id}: {e}\n{traceback.format_exc()}")
        return jsonify({'error': f'Crawl failed: {str(e)}'}), 500


@monitoring_bp.route('/competitors/discover', methods=['POST'])
@token_required
def discover_competitors(current_user):
    """
    Discover competitors based on industry and location
    
    POST /api/monitoring/competitors/discover
    {
        "industry": "hvac",
        "geo": "Sarasota, FL",
        "keywords": ["ac repair", "hvac service"]
    }
    """
    data = request.get_json(silent=True) or {}
    
    industry = data.get('industry', '')
    geo = data.get('geo', '')
    keywords = data.get('keywords', [])
    
    # Build search query
    search_terms = []
    if industry:
        search_terms.append(industry)
    if keywords:
        search_terms.extend(keywords[:3])  # Use top 3 keywords
    if geo:
        search_terms.append(geo)
    
    # For now, return demo data - in production this would use Google Search API or similar
    # This simulates finding competitors in the local market
    demo_competitors = [
        {
            'domain': f'{industry.lower().replace("_", "")}pro.com' if industry else 'localcompetitor1.com',
            'name': f'Local {industry.replace("_", " ").title()} Pro' if industry else 'Local Competitor 1',
            'pages': 45,
            'blogs': 12,
            'discovered_via': 'keyword_search'
        },
        {
            'domain': f'{geo.split(",")[0].lower().replace(" ", "")}services.com' if geo else 'competitor2.com',
            'name': f'{geo.split(",")[0]} Services' if geo else 'Regional Competitor',
            'pages': 78,
            'blogs': 24,
            'discovered_via': 'location_search'
        },
        {
            'domain': 'nationalfranchise-local.com',
            'name': 'National Brand - Local Office',
            'pages': 120,
            'blogs': 56,
            'discovered_via': 'market_analysis'
        }
    ]
    
    return jsonify({
        'success': True,
        'competitors': demo_competitors,
        'search_query': ' '.join(search_terms),
        'message': 'Found 3 potential competitors in your market'
    })


@monitoring_bp.route('/competitors/<competitor_id>/pages', methods=['GET'])
@token_required
def get_competitor_pages(current_user, competitor_id):
    """Get all pages discovered from a competitor"""
    competitor = DBCompetitor.query.get(competitor_id)
    
    if not competitor:
        return jsonify({'error': 'Competitor not found'}), 404
    
    if not current_user.has_access_to_client(competitor.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    pages = DBCompetitorPage.query.filter_by(
        competitor_id=competitor_id
    ).order_by(DBCompetitorPage.discovered_at.desc()).limit(50).all()
    
    return jsonify({
        'competitor': competitor.to_dict(),
        'pages': [p.to_dict() for p in pages]
    })


# ==========================================
# AUTO CONTENT GENERATION
# ==========================================

@monitoring_bp.route('/counter-content', methods=['POST'])
@token_required
def generate_counter_content(current_user):
    """
    Generate content to beat a competitor page
    
    POST /api/monitoring/counter-content
    {
        "competitor_page_id": "cpage_abc123",
        "target_keyword": "roof repair sarasota"  // Optional override
    }
    """
    data = request.get_json(silent=True) or {}
    
    page_id = data.get('competitor_page_id')
    
    if not page_id:
        return jsonify({'error': 'competitor_page_id required'}), 400
    
    # Get competitor page
    comp_page = DBCompetitorPage.query.get(page_id)
    if not comp_page:
        return jsonify({'error': 'Competitor page not found'}), 404
    
    if not current_user.has_access_to_client(comp_page.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    # Get client
    client = DBClient.query.get(comp_page.client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    # Extract competitor content
    comp_content = competitor_monitoring_service.extract_page_content(comp_page.url)
    
    if comp_content.get('error'):
        return jsonify({'error': f'Could not fetch competitor content: {comp_content["error"]}'}), 400
    
    # Analyze competitor content
    analysis = competitor_monitoring_service.analyze_competitor_content(comp_content)
    
    # Determine target keyword
    target_keyword = data.get('target_keyword') or comp_page.h1 or comp_page.title
    # Clean up keyword
    target_keyword = target_keyword.split('|')[0].split('-')[0].strip()[:50]
    
    # Score competitor content
    comp_score = seo_scoring_engine.score_content(
        {
            'title': comp_content.get('title', ''),
            'meta_description': comp_content.get('meta_description', ''),
            'h1': comp_content.get('h1', ''),
            'body': '',
            'body_text': comp_content.get('body_text', '')
        },
        target_keyword,
        client.geo
    )
    
    # Generate superior content
    result = ai_service.generate_blog_post(
        keyword=target_keyword,
        geo=client.geo or '',
        industry=client.industry or '',
        word_count=analysis['recommended_word_count'],
        tone=client.tone or 'professional',
        business_name=client.business_name or '',
        include_faq=True,
        faq_count=5,
        internal_links=client.get_service_pages() or [],
        usps=client.get_unique_selling_points() or []
    )
    
    if result.get('error'):
        return jsonify({'error': f'Content generation failed: {result["error"]}'}), 500
    
    # Score our content
    our_score = seo_scoring_engine.score_content(
        {
            'title': result.get('title', ''),
            'meta_title': result.get('meta_title', ''),
            'meta_description': result.get('meta_description', ''),
            'h1': result.get('h1', ''),
            'body': result.get('body', ''),
            'body_text': result.get('body', '')
        },
        target_keyword,
        client.geo
    )
    
    # Add to content queue
    queued_content = DBContentQueue(
        client_id=client.id,
        trigger_type='competitor_post',
        trigger_competitor_id=comp_page.competitor_id,
        trigger_competitor_page_id=comp_page.id,
        trigger_keyword=target_keyword,
        title=result.get('title', ''),
        body=result.get('body', ''),
        meta_title=result.get('meta_title', ''),
        meta_description=result.get('meta_description', ''),
        primary_keyword=target_keyword,
        word_count=len(result.get('body', '').split()),
        our_seo_score=our_score['total_score'],
        competitor_seo_score=comp_score['total_score']
    )
    
    db.session.add(queued_content)
    
    # Mark competitor page as countered
    comp_page.was_countered = True
    comp_page.is_new = False
    
    # Create alert
    alert = DBAlert(
        client_id=client.id,
        alert_type='content_ready',
        title='Counter-content ready for review',
        message=f'"{result.get("title", "")}" - Score: {our_score["total_score"]} vs {comp_score["total_score"]}',
        related_competitor_id=comp_page.competitor_id,
        related_page_id=comp_page.id,
        related_content_id=queued_content.id,
        related_keyword=target_keyword,
        priority='high'
    )
    db.session.add(alert)
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'queued_content': queued_content.to_dict(),
        'comparison': {
            'our_score': our_score['total_score'],
            'our_grade': our_score['grade'],
            'competitor_score': comp_score['total_score'],
            'competitor_grade': comp_score['grade'],
            'our_word_count': queued_content.word_count,
            'competitor_word_count': comp_content.get('word_count', 0),
            'we_win': our_score['total_score'] > comp_score['total_score']
        }
    })


# ==========================================
# CONTENT QUEUE
# ==========================================

@monitoring_bp.route('/queue', methods=['GET'])
@token_required
def get_content_queue(current_user):
    """Get pending content queue for a client"""
    client_id = request.args.get('client_id')
    status = request.args.get('status', 'pending')
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    query = DBContentQueue.query.filter_by(client_id=client_id)
    
    if status != 'all':
        query = query.filter_by(status=status)
    
    items = query.order_by(DBContentQueue.created_at.desc()).limit(50).all()
    
    return jsonify({
        'client_id': client_id,
        'queue': [item.to_dict() for item in items]
    })


@monitoring_bp.route('/queue/<item_id>', methods=['GET'])
@token_required
def get_queue_item(current_user, item_id):
    """Get full content for a queue item"""
    item = DBContentQueue.query.get(item_id)
    
    if not item:
        return jsonify({'error': 'Item not found'}), 404
    
    if not current_user.has_access_to_client(item.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    result = item.to_dict()
    result['body'] = item.body  # Include full body
    
    # Get competitor page info if available
    if item.trigger_competitor_page_id:
        comp_page = DBCompetitorPage.query.get(item.trigger_competitor_page_id)
        if comp_page:
            result['competitor_page'] = comp_page.to_dict()
    
    return jsonify(result)


@monitoring_bp.route('/queue/<item_id>/approve', methods=['POST'])
@token_required
def approve_queue_item(current_user, item_id):
    """
    Approve queued content → creates blog post
    
    POST /api/monitoring/queue/{id}/approve
    {
        "publish_immediately": false  // Optional
    }
    """
    item = DBContentQueue.query.get(item_id)
    
    if not item:
        return jsonify({'error': 'Item not found'}), 404
    
    if not current_user.has_access_to_client(item.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    if item.status != 'pending':
        return jsonify({'error': f'Item is already {item.status}'}), 400
    
    data = request.get_json(silent=True) or {}
    
    # Get client for tag generation
    client = DBClient.query.get(item.client_id)
    geo = (client.geo or '') if client else ''
    geo_parts = geo.split(',') if geo else ['']
    mon_city = geo_parts[0].strip() if geo_parts else ''
    
    from app.routes.content import _generate_blog_tags
    
    # Create blog post
    blog_post = DBBlogPost(
        client_id=item.client_id,
        title=item.title,
        body=item.body,
        meta_title=item.meta_title,
        meta_description=item.meta_description,
        primary_keyword=item.primary_keyword,
        secondary_keywords=[],
        faq_content=[],
        word_count=item.word_count,
        target_city=mon_city,
        tags=_generate_blog_tags(item.primary_keyword, city=mon_city, industry=client.industry if client else ''),
        status=ContentStatus.APPROVED
    )
    
    db.session.add(blog_post)
    
    # Update queue item
    item.status = 'approved'
    item.approved_by = current_user.id
    item.approved_at = datetime.utcnow()
    item.published_blog_id = blog_post.id
    
    # Update competitor page
    if item.trigger_competitor_page_id:
        comp_page = DBCompetitorPage.query.get(item.trigger_competitor_page_id)
        if comp_page:
            comp_page.counter_content_id = blog_post.id
    
    db.session.commit()
    
    return jsonify({
        'message': 'Content approved',
        'blog_post': blog_post.to_dict()
    })


@monitoring_bp.route('/queue/<item_id>/reject', methods=['POST'])
@token_required
def reject_queue_item(current_user, item_id):
    """Reject queued content"""
    item = DBContentQueue.query.get(item_id)
    
    if not item:
        return jsonify({'error': 'Item not found'}), 404
    
    if not current_user.has_access_to_client(item.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.get_json(silent=True) or {}
    
    item.status = 'rejected'
    item.client_notes = data.get('notes', '')
    
    db.session.commit()
    
    return jsonify({'message': 'Content rejected'})


@monitoring_bp.route('/queue/<item_id>/publish', methods=['POST'])
@token_required
def publish_queue_item(current_user, item_id):
    """
    Publish approved content to WordPress
    
    POST /api/monitoring/queue/{id}/publish
    """
    from app.services.wordpress_service import get_wordpress_manager
    
    item = DBContentQueue.query.get(item_id)
    
    if not item:
        return jsonify({'error': 'Item not found'}), 404
    
    if not current_user.has_access_to_client(item.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    if item.status != 'approved':
        return jsonify({'error': 'Content must be approved before publishing'}), 400
    
    # Get client's WordPress config
    client = DBClient.query.get(item.client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    if not client.wordpress_url:
        return jsonify({'error': 'WordPress not configured for this client. Add WordPress URL and credentials in client settings.'}), 400
    
    # Publish
    wp_manager = get_wordpress_manager()
    result = wp_manager.publish_content(item.client_id, item.id)
    
    if result.get('success'):
        return jsonify({
            'message': 'Published to WordPress',
            'url': result.get('url'),
            'post_id': result.get('post_id')
        })
    else:
        return jsonify({'error': result.get('error', 'Publishing failed')}), 500


@monitoring_bp.route('/queue/<item_id>/regenerate', methods=['POST'])
@token_required
def regenerate_queue_item(current_user, item_id):
    """
    Regenerate content with notes
    
    POST /api/monitoring/queue/{id}/regenerate
    {
        "notes": "Make it more conversational, add more local references"
    }
    """
    item = DBContentQueue.query.get(item_id)
    
    if not item:
        return jsonify({'error': 'Item not found'}), 404
    
    if not current_user.has_access_to_client(item.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    if item.regenerate_count >= 3:
        return jsonify({'error': 'Maximum regeneration limit reached'}), 400
    
    data = request.get_json(silent=True) or {}
    notes = data.get('notes', '')
    
    # Get client
    client = DBClient.query.get(item.client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    # Regenerate with notes incorporated into prompt
    result = ai_service.generate_blog_post(
        keyword=item.primary_keyword,
        geo=client.geo or '',
        industry=client.industry or '',
        word_count=max(item.word_count, 1200),
        tone=client.tone or 'professional',
        business_name=client.business_name or '',
        include_faq=True,
        faq_count=5,
        usps=client.get_unique_selling_points() or []
        # Note: In production, pass notes to AI prompt
    )
    
    if result.get('error'):
        return jsonify({'error': f'Regeneration failed: {result["error"]}'}), 500
    
    # Score new content
    our_score = seo_scoring_engine.score_content(
        {
            'title': result.get('title', ''),
            'meta_title': result.get('meta_title', ''),
            'meta_description': result.get('meta_description', ''),
            'h1': result.get('h1', ''),
            'body': result.get('body', ''),
            'body_text': result.get('body', '')
        },
        item.primary_keyword,
        client.geo
    )
    
    # Update item
    item.title = result.get('title', '')
    item.body = result.get('body', '')
    item.meta_title = result.get('meta_title', '')
    item.meta_description = result.get('meta_description', '')
    item.word_count = len(result.get('body', '').split())
    item.our_seo_score = our_score['total_score']
    item.client_notes = notes
    item.regenerate_count += 1
    item.status = 'pending'
    
    db.session.commit()
    
    return jsonify({
        'message': 'Content regenerated',
        'queued_content': item.to_dict(),
        'new_score': our_score['total_score']
    })


# ==========================================
# RANK TRACKING
# ==========================================

@monitoring_bp.route('/rankings', methods=['GET'])
@token_required
def get_rankings(current_user):
    """Get current rankings for a client"""
    import os
    
    client_id = request.args.get('client_id')
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    client = DBClient.query.get(client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    try:
        # Get keywords to track
        keywords = client.get_primary_keywords() + client.get_secondary_keywords()
        
        if not keywords:
            return jsonify({'error': 'No keywords configured for client'}), 400
        
        # Debug: Check if API key is available
        api_key_set = bool(os.environ.get('SEMRUSH_API_KEY'))
        service_key_set = bool(rank_tracking_service.api_key)
        
        # Check rankings
        result = rank_tracking_service.check_all_keywords(
            client.website_url or client.business_name,
            keywords[:50]  # Limit to 50 keywords
        )
        
        # Add debug info to result
        result['_debug'] = {
            'env_var_set': api_key_set,
            'service_key_set': service_key_set,
            'key_length': len(os.environ.get('SEMRUSH_API_KEY', ''))
        }
        
        # Don't treat demo_mode results as errors - they're valid responses
        # Only return 500 for actual server errors, not SEMrush "nothing found"
        if result.get('error') and not result.get('demo_mode'):
            return jsonify({'error': result['error']}), 500
        
        # Get previous rankings from database to calculate changes if not provided by SEMrush
        try:
            # Get last ranking check for each keyword (from 1-7 days ago)
            from sqlalchemy import func
            seven_days_ago = datetime.utcnow() - timedelta(days=7)
            one_day_ago = datetime.utcnow() - timedelta(days=1)
            
            # Get the most recent previous position for each keyword
            previous_rankings = {}
            for kw_data in result.get('keywords', []):
                keyword = kw_data['keyword']
                # Find the last recorded position (at least 1 day old to avoid same-day duplicates)
                last_record = DBRankHistory.query.filter(
                    DBRankHistory.client_id == client_id,
                    DBRankHistory.keyword == keyword,
                    DBRankHistory.checked_at < one_day_ago,
                    DBRankHistory.checked_at >= seven_days_ago
                ).order_by(DBRankHistory.checked_at.desc()).first()
                
                if last_record and last_record.position:
                    previous_rankings[keyword] = last_record.position
            
            # Update keywords with calculated changes if SEMrush didn't provide them
            for kw_data in result.get('keywords', []):
                keyword = kw_data['keyword']
                current_pos = kw_data.get('position')
                
                # If no change from SEMrush but we have historical data
                if kw_data.get('change', 0) == 0 and current_pos and keyword in previous_rankings:
                    prev_pos = previous_rankings[keyword]
                    kw_data['previous_position'] = prev_pos
                    kw_data['change'] = prev_pos - current_pos  # Positive = improved
                    logger.debug(f"Calculated change for '{keyword}': {prev_pos} -> {current_pos} = {kw_data['change']}")
        except Exception as e:
            logger.warning(f"Could not calculate historical changes: {e}")
        
        # Save to history (only if not demo mode)
        if not result.get('demo_mode'):
            for kw_data in result.get('keywords', []):
                history = DBRankHistory(
                    client_id=client_id,
                    keyword=kw_data['keyword'],
                    position=kw_data.get('position'),
                    previous_position=kw_data.get('previous_position'),
                    change=kw_data.get('change', 0),
                    url=kw_data.get('url', ''),
                    search_volume=kw_data.get('search_volume', 0),
                    cpc=kw_data.get('cpc', 0.0)
                )
                db.session.add(history)
            
            db.session.commit()
        
        # Calculate traffic value
        traffic_value = rank_tracking_service.calculate_traffic_value(result.get('keywords', []))
        
        result['traffic_value'] = traffic_value
        
        return jsonify(result)
        
    except Exception as e:
        import traceback
        logger.error(f"Rankings error for client {client_id}: {e}\n{traceback.format_exc()}")
        return jsonify({'error': f'Server error: {str(e)}'}), 500


@monitoring_bp.route('/rankings/latest', methods=['GET'])
@token_required
def get_latest_rankings(current_user):
    """Get the most recent cached rankings from DB — does NOT call SEMrush API.
    Used by SEO Overview to show rankings without burning API units."""
    client_id = request.args.get('client_id')
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    client = DBClient.query.get(client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    try:
        from sqlalchemy import func, text
        
        # Get the latest ranking for each keyword (most recent check)
        subq = db.session.query(
            DBRankHistory.keyword,
            func.max(DBRankHistory.checked_at).label('latest')
        ).filter(
            DBRankHistory.client_id == client_id
        ).group_by(DBRankHistory.keyword).subquery()
        
        latest_rankings = db.session.query(DBRankHistory).join(
            subq,
            db.and_(
                DBRankHistory.keyword == subq.c.keyword,
                DBRankHistory.checked_at == subq.c.latest,
                DBRankHistory.client_id == client_id
            )
        ).all()
        
        if not latest_rankings:
            return jsonify({
                'keywords': [],
                'cached': True,
                'message': 'No cached rankings. Click "Check Now" to fetch from SEMrush.'
            })
        
        keywords = []
        for r in latest_rankings:
            keywords.append({
                'keyword': r.keyword,
                'position': r.position,
                'previous_position': r.previous_position,
                'change': r.change or 0,
                'url': r.url or '',
                'search_volume': r.search_volume or 0,
                'cpc': r.cpc or 0.0,
                'checked_at': r.checked_at.isoformat() if r.checked_at else None
            })
        
        # Calculate summary
        ranked = [k for k in keywords if k['position'] and k['position'] <= 100]
        
        return jsonify({
            'keywords': keywords,
            'cached': True,
            'checked_at': max(r.checked_at for r in latest_rankings).isoformat() if latest_rankings else None,
            'summary': {
                'total': len(keywords),
                'in_top_3': sum(1 for k in keywords if k['position'] and k['position'] <= 3),
                'in_top_10': sum(1 for k in keywords if k['position'] and k['position'] <= 10),
                'in_top_20': sum(1 for k in keywords if k['position'] and k['position'] <= 20),
                'not_ranking': sum(1 for k in keywords if not k['position'] or k['position'] > 100)
            }
        })
    except Exception as e:
        logger.error(f"Error getting latest rankings: {e}")
        return jsonify({'error': str(e)}), 500


@monitoring_bp.route('/rankings/history', methods=['GET'])
@token_required
def get_ranking_history(current_user):
    """Get ranking history for a client"""
    client_id = request.args.get('client_id')
    days = safe_int(request.args.get('days'), 30, max_val=365)
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    since = datetime.utcnow() - timedelta(days=days)
    
    history = DBRankHistory.query.filter(
        DBRankHistory.client_id == client_id,
        DBRankHistory.checked_at >= since
    ).order_by(DBRankHistory.checked_at.desc()).all()
    
    return jsonify({
        'client_id': client_id,
        'days': days,
        'history': [h.to_dict() for h in history]
    })


@monitoring_bp.route('/rankings/heatmap', methods=['GET'])
@token_required
def get_ranking_heatmap(current_user):
    """Get heatmap data for rankings dashboard"""
    client_id = request.args.get('client_id')
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    # Get latest rankings
    latest = DBRankHistory.query.filter_by(client_id=client_id).order_by(
        DBRankHistory.checked_at.desc()
    ).limit(100).all()
    
    # Get 7-day ago rankings
    seven_days_ago = datetime.utcnow() - timedelta(days=7)
    history_7d = DBRankHistory.query.filter(
        DBRankHistory.client_id == client_id,
        DBRankHistory.checked_at <= seven_days_ago,
        DBRankHistory.checked_at >= seven_days_ago - timedelta(hours=24)
    ).all()
    
    # Get 30-day ago rankings
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    history_30d = DBRankHistory.query.filter(
        DBRankHistory.client_id == client_id,
        DBRankHistory.checked_at <= thirty_days_ago,
        DBRankHistory.checked_at >= thirty_days_ago - timedelta(hours=24)
    ).all()
    
    # Generate heatmap
    heatmap = rank_tracking_service.generate_heatmap_data(
        [h.to_dict() for h in latest],
        [h.to_dict() for h in history_7d],
        [h.to_dict() for h in history_30d]
    )
    
    return jsonify({
        'client_id': client_id,
        'heatmap': heatmap
    })


# ==========================================
# ALERTS
# ==========================================

@monitoring_bp.route('/alerts', methods=['GET'])
@token_required
def get_alerts(current_user):
    """Get alerts for a client"""
    client_id = request.args.get('client_id')
    unread_only = request.args.get('unread_only', 'false').lower() == 'true'
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    query = DBAlert.query.filter_by(client_id=client_id)
    
    if unread_only:
        query = query.filter_by(is_read=False)
    
    alerts = query.order_by(DBAlert.created_at.desc()).limit(50).all()
    
    return jsonify({
        'client_id': client_id,
        'alerts': [a.to_dict() for a in alerts]
    })


@monitoring_bp.route('/alerts/<alert_id>/read', methods=['POST'])
@token_required
def mark_alert_read(current_user, alert_id):
    """Mark an alert as read"""
    alert = DBAlert.query.get(alert_id)
    
    if not alert:
        return jsonify({'error': 'Alert not found'}), 404
    
    if not current_user.has_access_to_client(alert.client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    alert.is_read = True
    db.session.commit()
    
    return jsonify({'message': 'Alert marked as read'})


# ==========================================
# SEO SCORING
# ==========================================

@monitoring_bp.route('/seo-score', methods=['POST'])
@token_required
def score_content(current_user):
    """
    Score content against SEO best practices
    
    POST /api/monitoring/seo-score
    {
        "content": {
            "title": "...",
            "meta_title": "...",
            "meta_description": "...",
            "h1": "...",
            "body": "HTML content..."
        },
        "target_keyword": "roof repair sarasota",
        "location": "Sarasota, FL"
    }
    """
    data = request.get_json(silent=True) or {}
    
    content = data.get('content', {})
    keyword = data.get('target_keyword', '')
    location = data.get('location', '')
    
    if not content or not keyword:
        return jsonify({'error': 'content and target_keyword required'}), 400
    
    score = seo_scoring_engine.score_content(content, keyword, location)
    
    return jsonify(score)


@monitoring_bp.route('/seo-compare', methods=['POST'])
@token_required
def compare_content(current_user):
    """
    Compare our content against competitor content
    
    POST /api/monitoring/seo-compare
    {
        "our_content": {...},
        "competitor_url": "https://...",
        "target_keyword": "...",
        "location": "..."
    }
    """
    data = request.get_json(silent=True) or {}
    
    our_content = data.get('our_content', {})
    competitor_url = data.get('competitor_url', '')
    keyword = data.get('target_keyword', '')
    location = data.get('location', '')
    
    if not our_content or not competitor_url or not keyword:
        return jsonify({'error': 'our_content, competitor_url, and target_keyword required'}), 400
    
    # Fetch competitor content
    comp_extracted = competitor_monitoring_service.extract_page_content(competitor_url)
    
    if comp_extracted.get('error'):
        return jsonify({'error': f'Could not fetch competitor: {comp_extracted["error"]}'}), 400
    
    comp_content = {
        'title': comp_extracted.get('title', ''),
        'meta_description': comp_extracted.get('meta_description', ''),
        'h1': comp_extracted.get('h1', ''),
        'body': '',
        'body_text': comp_extracted.get('body_text', '')
    }
    
    comparison = seo_scoring_engine.compare_content(
        our_content,
        comp_content,
        keyword,
        location
    )
    
    return jsonify(comparison)


@monitoring_bp.route('/analyze-url', methods=['POST'])
@token_required
def analyze_url(current_user):
    """
    Analyze a URL for SEO metrics
    
    POST /api/monitoring/analyze-url
    {
        "url": "https://competitor.com/blog-post"
    }
    """
    data = request.get_json(silent=True) or {}
    url = data.get('url', '').strip()
    
    if not url:
        return jsonify({'error': 'url is required'}), 400
    
    try:
        # Use competitor monitoring service to extract content
        page_data = competitor_monitoring_service.extract_page_content(url)
        
        if page_data.get('error'):
            return jsonify({'error': page_data['error']}), 400
        
        # Count elements for SEO analysis
        body_text = page_data.get('body_text', '')
        h2s = page_data.get('h2s', [])
        
        # Count internal links (simplified)
        internal_links = 0
        external_links = 0
        
        return jsonify({
            'success': True,
            'url': url,
            'title': page_data.get('title', ''),
            'meta_description': page_data.get('meta_description', ''),
            'h1': page_data.get('h1', ''),
            'h2s': h2s,
            'h2_count': len(h2s),
            'word_count': page_data.get('word_count', 0),
            'internal_links': internal_links,
            'external_links': external_links,
            'content_hash': page_data.get('content_hash', '')
        })
        
    except Exception as e:
        logger.error(f"URL analysis error: {e}")
        return jsonify({'error': 'Failed to analyze URL'}), 500


# ==========================================
# DASHBOARD DATA
# ==========================================

@monitoring_bp.route('/dashboard', methods=['GET'])
@token_required
def get_dashboard_data(current_user):
    """
    Get all data needed for the monitoring dashboard
    
    GET /api/monitoring/dashboard?client_id=xxx
    """
    client_id = request.args.get('client_id')
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    client = DBClient.query.get(client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    # Competitors
    competitors = DBCompetitor.query.filter_by(
        client_id=client_id,
        is_active=True
    ).all()
    
    # New competitor pages (last 7 days)
    seven_days_ago = datetime.utcnow() - timedelta(days=7)
    new_pages = DBCompetitorPage.query.filter(
        DBCompetitorPage.client_id == client_id,
        DBCompetitorPage.discovered_at >= seven_days_ago
    ).order_by(DBCompetitorPage.discovered_at.desc()).limit(10).all()
    
    # Content queue (from competitor monitoring)
    pending_content = DBContentQueue.query.filter_by(
        client_id=client_id,
        status='pending'
    ).count()
    
    # Also count draft blog posts as "content ready for review"
    draft_posts = DBBlogPost.query.filter_by(
        client_id=client_id,
        status=ContentStatus.DRAFT
    ).count()
    
    # Total content ready = queue items + draft posts
    total_content_ready = pending_content + draft_posts
    
    # Recent alerts
    alerts = DBAlert.query.filter_by(
        client_id=client_id,
        is_read=False
    ).order_by(DBAlert.created_at.desc()).limit(5).all()
    
    # Latest rankings
    latest_rankings = DBRankHistory.query.filter_by(
        client_id=client_id
    ).order_by(DBRankHistory.checked_at.desc()).limit(50).all()
    
    # Calculate stats
    keywords = client.get_primary_keywords() + client.get_secondary_keywords()
    
    # Ranking summary
    ranking_summary = {
        'total_keywords': len(keywords),
        'in_top_3': 0,
        'in_top_10': 0,
        'improved_7d': 0,
        'declined_7d': 0
    }
    
    seen_keywords = set()
    for r in latest_rankings:
        if r.keyword not in seen_keywords:
            seen_keywords.add(r.keyword)
            if r.position:
                if r.position <= 3:
                    ranking_summary['in_top_3'] += 1
                if r.position <= 10:
                    ranking_summary['in_top_10'] += 1
    
    return jsonify({
        'client': client.to_dict(),
        'stats': {
            'competitors_tracked': len(competitors),
            'new_content_detected': len(new_pages),
            'content_pending_review': total_content_ready,
            'draft_posts': draft_posts,
            'unread_alerts': len(alerts),
            'keywords_tracked': len(keywords)
        },
        'ranking_summary': ranking_summary,
        'competitors': [c.to_dict() for c in competitors],
        'new_competitor_pages': [p.to_dict() for p in new_pages],
        'recent_alerts': [a.to_dict() for a in alerts],
        'system_status': 'active'
    })


# ==========================================
# CONTENT CHANGE DETECTION
# ==========================================

@monitoring_bp.route('/content-changes/<client_id>', methods=['GET'])
@token_required
def get_content_changes(current_user, client_id):
    """
    Get recent content changes detected from competitors
    
    GET /api/monitoring/content-changes/{client_id}
    
    Returns list of new pages and content updates
    """
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    # Get competitors for this client
    competitors = DBCompetitor.query.filter_by(
        client_id=client_id,
        is_active=True
    ).all()
    
    changes = []
    
    for competitor in competitors:
        # Get pages discovered in last 7 days
        recent_pages = DBCompetitorPage.query.filter(
            DBCompetitorPage.competitor_id == competitor.id,
            DBCompetitorPage.discovered_at >= datetime.utcnow() - timedelta(days=7)
        ).order_by(DBCompetitorPage.discovered_at.desc()).limit(10).all()
        
        for page in recent_pages:
            changes.append({
                'type': 'new_page',
                'competitor': competitor.domain or '',
                'competitor_id': competitor.id,
                'url': page.url or '',
                'title': page.title or 'Untitled',
                'word_count': page.word_count or 0,
                'detected_at': page.discovered_at.isoformat() if page.discovered_at else None
            })
    
    # Sort by detected_at descending
    changes.sort(key=lambda x: x.get('detected_at') or '', reverse=True)
    
    return jsonify({
        'client_id': client_id,
        'changes': changes[:20],  # Limit to 20 most recent
        'scanned_at': datetime.utcnow().isoformat()
    })


@monitoring_bp.route('/rank-history/<client_id>', methods=['GET'])
@token_required
def get_rank_history(current_user, client_id):
    """
    Get rank history for a keyword
    
    GET /api/monitoring/rank-history/{client_id}?keyword=ac+repair+tampa
    
    Returns 30-day position history
    """
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    keyword = request.args.get('keyword', '')
    if not keyword:
        return jsonify({'error': 'keyword parameter required'}), 400
    
    # Get rank history for this keyword
    history = DBRankHistory.query.filter(
        DBRankHistory.client_id == client_id,
        DBRankHistory.keyword == keyword,
        DBRankHistory.checked_at >= datetime.utcnow() - timedelta(days=30)
    ).order_by(DBRankHistory.checked_at.asc()).all()
    
    if not history:
        # Return empty but valid response
        return jsonify({
            'client_id': client_id,
            'keyword': keyword,
            'history': [],
            'message': 'No rank history found for this keyword'
        })
    
    return jsonify({
        'client_id': client_id,
        'keyword': keyword,
        'history': [
            {
                'date': h.checked_at.isoformat() if h.checked_at else None,
                'position': h.position,
                'url': getattr(h, 'ranking_url', None) or getattr(h, 'url', None) or ''
            }
            for h in history
        ]
    })


# ==========================================
# COMPETITOR DASHBOARD
# ==========================================

@monitoring_bp.route('/competitor-dashboard/<client_id>', methods=['GET'])
@token_required
def get_competitor_dashboard(current_user, client_id):
    """
    Get comprehensive competitor comparison data for dashboard
    
    GET /api/monitoring/competitor-dashboard/{client_id}
    
    Returns:
    - Client vs competitor rankings overview
    - Content gap analysis
    - Keyword overlap
    - Competitor content summary
    """
    import logging
    logger = logging.getLogger(__name__)
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    client = DBClient.query.get(client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    def normalize_domain(d):
        """Normalize domain for comparison"""
        if not d:
            return ''
        return d.lower().replace('www.', '').replace('https://', '').replace('http://', '').strip('/').strip()
    
    # Get competitors from client.competitors JSON field (from settings edit screen)
    # This is the SINGLE SOURCE OF TRUTH
    settings_domains = set()
    try:
        if client.competitors:
            import json
            client_comps = json.loads(client.competitors) if isinstance(client.competitors, str) else client.competitors
            if isinstance(client_comps, list):
                for comp in client_comps:
                    if isinstance(comp, str):
                        domain = normalize_domain(comp)
                    elif isinstance(comp, dict):
                        domain = normalize_domain(comp.get('domain') or comp.get('url') or '')
                    else:
                        continue
                    if domain:
                        settings_domains.add(domain)
    except Exception as e:
        logger.warning(f"Error parsing client.competitors: {e}")
    
    logger.info(f"Settings domains (source of truth): {settings_domains}")
    
    # Get all DBCompetitor entries for this client
    all_db_competitors = DBCompetitor.query.filter_by(client_id=client_id).all()
    
    # Sync DBCompetitor table with settings
    final_competitors = []
    seen_domains = set()
    
    # Deactivate/remove any DBCompetitor NOT in settings
    for db_comp in all_db_competitors:
        domain = normalize_domain(db_comp.domain)
        if domain not in settings_domains:
            # This competitor is not in settings - deactivate it
            if db_comp.is_active:
                db_comp.is_active = False
                logger.info(f"Deactivated competitor not in settings: {db_comp.name} ({domain})")
        else:
            # This competitor IS in settings - make sure it's active
            if not db_comp.is_active:
                db_comp.is_active = True
                logger.info(f"Reactivated competitor: {db_comp.name} ({domain})")
            if domain not in seen_domains:
                final_competitors.append(db_comp)
                seen_domains.add(domain)
    
    # Create DBCompetitor entries for any in settings that don't exist yet
    for domain in settings_domains:
        if domain not in seen_domains:
            name = domain.split('.')[0].replace('-', ' ').title()
            try:
                # Check if there's an existing one with this domain (active or inactive)
                # Use case-insensitive search
                existing = None
                for db_comp in all_db_competitors:
                    if normalize_domain(db_comp.domain) == domain:
                        existing = db_comp
                        break
                
                if existing:
                    if not existing.is_active:
                        existing.is_active = True
                        logger.info(f"Reactivated existing competitor: {existing.name} ({domain})")
                    final_competitors.append(existing)
                else:
                    # Create new competitor
                    new_comp = DBCompetitor(
                        client_id=client_id,
                        name=name,
                        domain=domain,
                        is_active=True
                    )
                    db.session.add(new_comp)
                    db.session.flush()  # Flush to get the ID
                    final_competitors.append(new_comp)
                    logger.info(f"Created new competitor from settings: {name} ({domain})")
                seen_domains.add(domain)
            except Exception as e:
                logger.error(f"Error creating competitor {domain}: {e}")
                import traceback
                logger.error(traceback.format_exc())
    
    try:
        db.session.commit()
        logger.info(f"Committed {len(final_competitors)} competitors: {[c.domain for c in final_competitors]}")
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error committing competitor changes: {e}")
        import traceback
        logger.error(traceback.format_exc())
    
    competitors = final_competitors
    logger.info(f"Final competitor count: {len(competitors)}")
    
    # Get client keywords
    client_keywords = []
    try:
        client_keywords = (client.get_primary_keywords() + client.get_secondary_keywords())[:20]
    except Exception:
        pass
    
    # Get client's SEMrush domain rankings (all keywords client ranks for)
    client_rankings = {}
    client_domain = rank_tracking_service._clean_domain(client.website_url or client.business_name)
    
    import requests as http_requests
    api_key = rank_tracking_service.api_key
    
    # FIRST: Try to load from DB rank history (FREE — no API units)
    try:
        from sqlalchemy import func
        # Get the latest ranking for each keyword from DB
        subq = db.session.query(
            DBRankHistory.keyword,
            func.max(DBRankHistory.checked_at).label('latest')
        ).filter(
            DBRankHistory.client_id == client_id
        ).group_by(DBRankHistory.keyword).subquery()
        
        latest_ranks = db.session.query(DBRankHistory).join(
            subq,
            db.and_(
                DBRankHistory.keyword == subq.c.keyword,
                DBRankHistory.checked_at == subq.c.latest,
                DBRankHistory.client_id == client_id
            )
        ).all()
        
        for rank in latest_ranks:
            keyword = getattr(rank, 'keyword', None)
            if keyword and getattr(rank, 'position', None):
                client_rankings[keyword.lower()] = {
                    'position': rank.position,
                    'url': getattr(rank, 'url', None) or '',
                    'change': getattr(rank, 'change', 0) or 0,
                    'search_volume': getattr(rank, 'search_volume', 0) or 0
                }
        logger.info(f"Loaded {len(client_rankings)} client rankings from DB cache")
    except Exception as e:
        logger.warning(f"Error loading cached rankings: {e}")
    
    # ONLY call SEMrush API if DB has nothing AND force_refresh param is set
    force_refresh = request.args.get('refresh') == '1'
    if not client_rankings and force_refresh and api_key:
        try:
            params = {
                'type': 'domain_organic',
                'key': api_key,
                'display_limit': 100,
                'export_columns': 'Ph,Po,Pp,Ur,Nq',
                'domain': client_domain,
                'database': rank_tracking_service.default_database
            }
            resp = http_requests.get(rank_tracking_service.base_url, params=params, timeout=30)
            if resp.status_code == 200 and not resp.text.startswith('ERROR'):
                lines = resp.text.strip().split('\n')
                for line in lines[1:]:
                    parts = line.split(';')
                    if len(parts) >= 5:
                        kw = parts[0].strip('"').lower()
                        pos = int(parts[1]) if parts[1] else None
                        if pos:
                            client_rankings[kw] = {
                                'position': pos,
                                'url': parts[3].strip('"') if parts[3] else '',
                                'change': (int(parts[2]) - pos) if parts[2] else 0,
                                'search_volume': int(parts[4]) if parts[4] else 0
                            }
            elif resp.text.startswith('ERROR'):
                logger.warning(f"SEMrush API error for client: {resp.text[:100]}")
        except Exception as e:
            logger.warning(f"Error fetching client SEMrush data: {e}")
    
    logger.info(f"Client {client_domain} has {len(client_rankings)} ranked keywords")
    
    # Build competitor comparison data
    competitor_data = []
    content_gaps = []
    keyword_overlap = []
    
    for comp in competitors[:10]:  # Limit to 10 competitors max
        # Get competitor pages (limited)
        try:
            comp_pages = DBCompetitorPage.query.filter_by(competitor_id=comp.id).limit(50).all()
        except Exception:
            comp_pages = []
        
        # Get competitor rankings — use DB cached data, NOT live SEMrush API
        # This avoids burning 200+ API units per competitor per page load
        comp_ranks = {}
        try:
            comp_domain = rank_tracking_service._clean_domain(comp.domain)
            
            # Try DB rank history for this competitor (stored from previous explicit checks)
            # Competitors don't have their own rank history in DB, so use SEMrush ONLY on explicit refresh
            if force_refresh and api_key:
                comp_params = {
                    'type': 'domain_organic',
                    'key': api_key,
                    'display_limit': 50,
                    'export_columns': 'Ph,Po,Nq',
                    'domain': comp_domain,
                    'database': rank_tracking_service.default_database
                }
                comp_resp = http_requests.get(rank_tracking_service.base_url, params=comp_params, timeout=10)
                if comp_resp.status_code == 200 and not comp_resp.text.startswith('ERROR'):
                    comp_lines = comp_resp.text.strip().split('\n')
                    for line in comp_lines[1:]:
                        parts = line.split(';')
                        if len(parts) >= 2:
                            kw = parts[0].strip('"').lower()
                            try:
                                pos = int(parts[1]) if parts[1] else None
                            except ValueError:
                                continue
                            if pos:
                                comp_ranks[kw] = pos
                    logger.info(f"Competitor {comp_domain}: {len(comp_ranks)} ranked keywords (fresh)")
                elif comp_resp.text.startswith('ERROR'):
                    logger.warning(f"SEMrush error for competitor {comp_domain}: {comp_resp.text[:100]}")
        except Exception as e:
            logger.warning(f"Error fetching competitor {comp.domain} rankings: {e}")
        
        # Count content by category
        blog_count = len([p for p in comp_pages if '/blog' in (p.url or '').lower()])
        service_count = len([p for p in comp_pages if any(x in (p.url or '').lower() for x in ['/service', '/about', '/contact'])])
        
        # Find keyword overlap with client
        client_kw_set = set(client_rankings.keys())
        comp_kw_set = set(comp_ranks.keys())
        overlap = client_kw_set.intersection(comp_kw_set)
        
        competitor_data.append({
            'id': comp.id,
            'domain': comp.domain,
            'name': comp.name or comp.domain,
            'total_pages': len(comp_pages),
            'blog_posts': blog_count,
            'service_pages': service_count,
            'crawl_frequency': comp.crawl_frequency or 'daily',
            'last_crawled': comp.last_crawl_at.isoformat() if comp.last_crawl_at else None,
            'keyword_overlap': list(overlap)[:10],
            'total_keywords': len(comp_ranks),
            'rankings': comp_ranks
        })
        
        # Find content gaps - topics competitors have that client doesn't
        for page in comp_pages:
            if page.title and '/blog' in (page.url or '').lower():
                title_lower = page.title.lower()
                has_similar = False
                for kw in client_keywords:
                    if kw.lower() in title_lower:
                        has_similar = True
                        break
                
                if not has_similar:
                    content_gaps.append({
                        'competitor': comp.domain,
                        'title': page.title,
                        'url': page.url,
                        'topic_suggestion': page.title,
                        'type': 'content'
                    })
        
        # SEMrush Keyword Gap — keywords competitor ranks for in top 20 that client doesn't rank for
        client_kw_set = set(client_rankings.keys())
        for kw, pos in comp_ranks.items():
            if pos <= 20 and kw not in client_kw_set:
                # Only include keywords with reasonable search volume potential
                # Filter out brand names and very long-tail
                if len(kw.split()) <= 5 and comp.domain.replace('.com','').replace('.net','').replace('www.','') not in kw:
                    content_gaps.append({
                        'competitor': comp.domain,
                        'title': kw.title(),
                        'url': '',
                        'topic_suggestion': kw,
                        'type': 'keyword',
                        'competitor_position': pos
                    })
    
    # Deduplicate and sort content gaps — keyword gaps first (more actionable), then by competitor position
    seen_gaps = set()
    unique_gaps = []
    for gap in content_gaps:
        key = gap.get('topic_suggestion', '').lower()
        if key not in seen_gaps:
            seen_gaps.add(key)
            unique_gaps.append(gap)
    
    # Sort: keyword gaps first (with position), then content gaps
    unique_gaps.sort(key=lambda x: (
        0 if x.get('type') == 'keyword' else 1,
        x.get('competitor_position', 100)
    ))
    content_gaps = unique_gaps
    
    # Calculate overall stats
    total_client_ranked = len([k for k, v in client_rankings.items() if v['position'] and v['position'] <= 100])
    top_10_count = len([k for k, v in client_rankings.items() if v['position'] and v['position'] <= 10])
    top_3_count = len([k for k, v in client_rankings.items() if v['position'] and v['position'] <= 3])
    
    # Ranking comparison - which keywords client wins vs loses
    ranking_battles = []
    for keyword, client_rank in client_rankings.items():
        if not client_rank['position']:
            continue
        
        for comp in competitor_data:
            comp_pos = comp['rankings'].get(keyword)
            if comp_pos:
                ranking_battles.append({
                    'keyword': keyword,
                    'client_position': client_rank['position'],
                    'competitor': comp['domain'],
                    'competitor_position': comp_pos,
                    'winning': client_rank['position'] < comp_pos,
                    'search_volume': client_rank.get('search_volume', 0)
                })
    
    # Sort battles by search volume (most valuable keywords first)
    ranking_battles.sort(key=lambda x: (-x.get('search_volume', 0), not x['winning']))
    
    # Strip large rankings dict from competitor data for response size
    for comp in competitor_data:
        comp['rankings'] = {}  # Don't send thousands of keywords to frontend
    
    return jsonify({
        'client_id': client_id,
        'client_name': client.business_name,
        'summary': {
            'total_competitors': len(competitors),
            'client_keywords_tracked': len(client_keywords),
            'client_keywords_ranked': total_client_ranked,
            'client_total_keywords': len(client_rankings),
            'top_10_keywords': top_10_count,
            'top_3_keywords': top_3_count,
            'content_gaps_found': len(content_gaps),
            'total_battles': len(ranking_battles)
        },
        'competitors': competitor_data,
        'content_gaps': content_gaps[:20],
        'ranking_battles': ranking_battles[:20],
        'client_rankings': {}  # Don't send huge dict
    })


@monitoring_bp.route('/competitor-compare/<client_id>/<competitor_id>', methods=['GET'])
@token_required
def compare_with_competitor(current_user, client_id, competitor_id):
    """
    Detailed side-by-side comparison with a single competitor
    
    GET /api/monitoring/competitor-compare/{client_id}/{competitor_id}
    """
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    client = DBClient.query.get(client_id)
    competitor = DBCompetitor.query.get(competitor_id)
    
    if not client or not competitor:
        return jsonify({'error': 'Client or competitor not found'}), 404
    
    if competitor.client_id != client_id:
        return jsonify({'error': 'Competitor does not belong to this client'}), 403
    
    # Get competitor pages
    comp_pages = DBCompetitorPage.query.filter_by(competitor_id=competitor_id).all()
    
    # Get client rankings
    client_rankings = {}
    latest_ranks = DBRankHistory.query.filter_by(client_id=client_id).order_by(
        DBRankHistory.checked_at.desc()
    ).limit(100).all()
    
    for rank in latest_ranks:
        if rank.keyword not in client_rankings:
            client_rankings[rank.keyword] = rank.position
    
    # Competitor rankings are not tracked in DBRankHistory
    # They would need to be tracked via a separate system
    comp_rankings = {}
    
    # All keywords from client
    all_keywords = set(client_rankings.keys())
    
    keyword_comparison = []
    client_wins = 0
    competitor_wins = 0
    ties = 0
    
    for keyword in all_keywords:
        client_pos = client_rankings.get(keyword)
        comp_pos = comp_rankings.get(keyword)
        
        if client_pos and comp_pos:
            if client_pos < comp_pos:
                winner = 'client'
                client_wins += 1
            elif comp_pos < client_pos:
                winner = 'competitor'
                competitor_wins += 1
            else:
                winner = 'tie'
                ties += 1
        elif client_pos:
            winner = 'client'
            client_wins += 1
        elif comp_pos:
            winner = 'competitor'
            competitor_wins += 1
        else:
            winner = 'unknown'
        
        keyword_comparison.append({
            'keyword': keyword,
            'client_position': client_pos,
            'competitor_position': comp_pos,
            'winner': winner,
            'gap': (comp_pos or 100) - (client_pos or 100) if client_pos or comp_pos else 0
        })
    
    # Sort by gap (biggest opportunities first)
    keyword_comparison.sort(key=lambda x: -abs(x['gap']))
    
    # Content comparison
    blog_pages = [p for p in comp_pages if '/blog' in (p.url or '').lower()]
    
    return jsonify({
        'client': {
            'id': client_id,
            'name': client.business_name,
            'website': client.website_url
        },
        'competitor': {
            'id': competitor_id,
            'name': competitor.name or competitor.domain,
            'domain': competitor.domain,
            'total_pages': len(comp_pages),
            'blog_posts': len(blog_pages),
            'last_crawled': competitor.last_crawled.isoformat() if competitor.last_crawled else None
        },
        'rankings_summary': {
            'total_keywords': len(all_keywords),
            'client_wins': client_wins,
            'competitor_wins': competitor_wins,
            'ties': ties,
            'win_rate': round(client_wins / len(all_keywords) * 100, 1) if all_keywords else 0
        },
        'keyword_comparison': keyword_comparison[:50],
        'competitor_content': [
            {
                'title': p.title,
                'url': p.url,
                'last_modified': p.last_modified.isoformat() if p.last_modified else None
            }
            for p in blog_pages[:20]
        ]
    })


# ==========================================
# CRAWL ALL COMPETITORS
# ==========================================

@monitoring_bp.route('/competitors/crawl-all', methods=['POST'])
@token_required
def crawl_all_competitors(current_user):
    """
    Crawl all competitors for a client
    
    POST /api/monitoring/competitors/crawl-all
    {
        "client_id": "client_abc123"
    }
    """
    data = request.get_json(silent=True) or {}
    client_id = data.get('client_id')
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    competitors = DBCompetitor.query.filter_by(
        client_id=client_id,
        is_active=True
    ).all()
    
    total_new_pages = 0
    competitors_crawled = 0
    errors = []
    
    for competitor in competitors:
        try:
            # Crawl competitor
            result = _crawl_single_competitor(competitor)
            competitors_crawled += 1
            total_new_pages += result.get('new_pages', 0)
        except Exception as e:
            errors.append(f"{competitor.domain}: {str(e)}")
    
    return jsonify({
        'success': True,
        'competitors_crawled': competitors_crawled,
        'total_new_pages': total_new_pages,
        'errors': errors if errors else None
    })


def _crawl_single_competitor(competitor):
    """Helper to crawl a single competitor - uses sitemap + blog page discovery"""
    import requests as http_requests
    from bs4 import BeautifulSoup
    from urllib.parse import urljoin, urlparse
    
    new_pages = 0
    crawled_urls = set()
    domain = competitor.domain
    base_url = f"https://{domain}"
    if not domain.startswith('www.'):
        base_url_www = f"https://www.{domain}"
    else:
        base_url_www = base_url
    
    headers = {'User-Agent': 'Mozilla/5.0 (compatible; MCPBot/1.0)'}
    
    # Get existing pages to avoid duplicates
    existing_urls = set()
    existing_pages = DBCompetitorPage.query.filter_by(competitor_id=competitor.id).all()
    for p in existing_pages:
        existing_urls.add(p.url)
    
    def save_page(url, title=''):
        nonlocal new_pages
        if url in existing_urls or url in crawled_urls:
            return
        crawled_urls.add(url)
        
        # Skip non-content URLs
        url_lower = url.lower()
        if any(x in url_lower for x in ['#', 'javascript:', 'mailto:', '.pdf', '.jpg', '.png', '.css', '.js', '/wp-admin', '/wp-json', '/feed', '/tag/', '/category/', '/author/', '/page/']):
            return
        
        if not title:
            title = url.split('/')[-1].replace('-', ' ').replace('_', ' ').strip().title() or url
        
        page = DBCompetitorPage(
            competitor_id=competitor.id,
            client_id=competitor.client_id,
            url=url,
            title=title[:300],
            discovered_at=datetime.utcnow()
        )
        db.session.add(page)
        new_pages += 1
    
    try:
        # Step 1: Try sitemap first (most comprehensive)
        sitemap_urls = [
            f'{base_url}/sitemap.xml',
            f'{base_url_www}/sitemap.xml',
            f'{base_url}/wp-sitemap.xml',
            f'{base_url}/sitemap_index.xml',
        ]
        
        sitemap_found = False
        for sitemap_url in sitemap_urls:
            try:
                resp = http_requests.get(sitemap_url, timeout=10, headers=headers)
                if resp.status_code == 200 and '<url' in resp.text.lower():
                    sitemap_found = True
                    soup = BeautifulSoup(resp.text, 'xml')
                    
                    # Handle sitemap index
                    sitemap_tags = soup.find_all('sitemap')
                    if sitemap_tags:
                        for sm in sitemap_tags[:10]:
                            loc = sm.find('loc')
                            if loc:
                                try:
                                    child_resp = http_requests.get(loc.text, timeout=10, headers=headers)
                                    if child_resp.status_code == 200:
                                        child_soup = BeautifulSoup(child_resp.text, 'xml')
                                        for url_tag in child_soup.find_all('url'):
                                            loc_tag = url_tag.find('loc')
                                            if loc_tag and domain in loc_tag.text:
                                                save_page(loc_tag.text)
                                except:
                                    continue
                    else:
                        # Regular sitemap
                        for url_tag in soup.find_all('url'):
                            loc = url_tag.find('loc')
                            if loc and domain in loc.text:
                                save_page(loc.text)
                    
                    break  # Found a working sitemap
            except:
                continue
        
        # Step 2: Crawl homepage for links
        try:
            resp = http_requests.get(base_url, timeout=10, headers=headers, allow_redirects=True)
            if resp.status_code == 200:
                soup = BeautifulSoup(resp.text, 'html.parser')
                for link in soup.find_all('a', href=True):
                    href = link.get('href', '')
                    full_url = urljoin(resp.url, href)
                    parsed = urlparse(full_url)
                    if domain in parsed.netloc:
                        title = link.get_text(strip=True)[:200]
                        save_page(full_url, title)
        except:
            pass
        
        # Step 3: Crawl /blog/ page for blog post links
        blog_urls = [f'{base_url}/blog/', f'{base_url}/blog', f'{base_url_www}/blog/', f'{base_url_www}/blog']
        for blog_url in blog_urls:
            try:
                resp = http_requests.get(blog_url, timeout=10, headers=headers, allow_redirects=True)
                if resp.status_code == 200:
                    soup = BeautifulSoup(resp.text, 'html.parser')
                    for link in soup.find_all('a', href=True):
                        href = link.get('href', '')
                        full_url = urljoin(resp.url, href)
                        parsed = urlparse(full_url)
                        if domain in parsed.netloc and '/blog' in full_url.lower():
                            title = link.get_text(strip=True)[:200]
                            save_page(full_url, title)
                    
                    # Check for pagination - crawl pages 2-5
                    for page_num in range(2, 6):
                        try:
                            page_url = f'{blog_url}page/{page_num}/'
                            resp2 = http_requests.get(page_url, timeout=10, headers=headers, allow_redirects=True)
                            if resp2.status_code == 200:
                                soup2 = BeautifulSoup(resp2.text, 'html.parser')
                                for link in soup2.find_all('a', href=True):
                                    href = link.get('href', '')
                                    full_url = urljoin(resp2.url, href)
                                    if domain in full_url and '/blog' in full_url.lower():
                                        title = link.get_text(strip=True)[:200]
                                        save_page(full_url, title)
                            else:
                                break  # No more pages
                        except:
                            break
                    break  # Found blog page
            except:
                continue
        
        # Update competitor
        competitor.last_crawl_at = datetime.utcnow()
        competitor.next_crawl_at = datetime.utcnow() + timedelta(days=1)
        competitor.known_pages_count = len(existing_urls) + new_pages
        
        db.session.commit()
        logger.info(f"Crawled {competitor.domain}: {new_pages} new pages found (total URLs checked: {len(crawled_urls)})")
        
    except Exception as e:
        logger.error(f"Crawl error for {competitor.domain}: {e}")
        return {'new_pages': 0, 'error': str(e)}
    
    return {'new_pages': new_pages}


# ==========================================
# CRAWL SETTINGS
# ==========================================

@monitoring_bp.route('/crawl-settings', methods=['POST'])
@token_required
def save_crawl_settings(current_user):
    """
    Save auto-crawl settings for a client
    
    POST /api/monitoring/crawl-settings
    {
        "client_id": "...",
        "crawl_frequency": "daily|weekly|manual",
        "crawl_hour": 3,       // 0-23 UTC
        "crawl_day": 0         // 0=Monday, 6=Sunday (for weekly)
    }
    """
    data = request.get_json(silent=True) or {}
    client_id = data.get('client_id')
    frequency = data.get('crawl_frequency', 'daily')
    crawl_hour = int(data.get('crawl_hour', 3))
    crawl_day = int(data.get('crawl_day', 0))
    
    # Validate
    crawl_hour = max(0, min(23, crawl_hour))
    crawl_day = max(0, min(6, crawl_day))
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    # Update all competitors for this client
    competitors = DBCompetitor.query.filter_by(
        client_id=client_id,
        is_active=True
    ).all()
    
    now = datetime.utcnow()
    
    for comp in competitors:
        comp.crawl_frequency = frequency
        comp.crawl_hour = crawl_hour
        comp.crawl_day = crawl_day
        
        if frequency == 'daily':
            # Next crawl today at crawl_hour, or tomorrow if already past
            next_run = now.replace(hour=crawl_hour, minute=0, second=0, microsecond=0)
            if next_run <= now:
                next_run += timedelta(days=1)
            comp.next_crawl_at = next_run
        elif frequency == 'weekly':
            # Next crawl on the specified weekday at crawl_hour
            days_ahead = crawl_day - now.weekday()
            if days_ahead < 0 or (days_ahead == 0 and now.hour >= crawl_hour):
                days_ahead += 7
            next_run = now.replace(hour=crawl_hour, minute=0, second=0, microsecond=0) + timedelta(days=days_ahead)
            comp.next_crawl_at = next_run
        else:
            comp.next_crawl_at = None
    
    db.session.commit()
    
    day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    schedule_desc = frequency
    if frequency == 'daily':
        schedule_desc = f"Daily at {crawl_hour:02d}:00 UTC"
    elif frequency == 'weekly':
        schedule_desc = f"Every {day_names[crawl_day]} at {crawl_hour:02d}:00 UTC"
    
    return jsonify({
        'success': True,
        'message': f'Crawl schedule set: {schedule_desc}',
        'schedule': schedule_desc,
        'competitors_updated': len(competitors),
        'next_crawl_at': competitors[0].next_crawl_at.isoformat() if competitors and competitors[0].next_crawl_at else None
    })


# ==========================================
# FRESHNESS ALERTS
# ==========================================

@monitoring_bp.route('/freshness-alerts', methods=['GET'])
@token_required
def get_freshness_alerts(current_user):
    """
    Get recent competitor content alerts
    
    GET /api/monitoring/freshness-alerts?client_id=xxx&days=7
    """
    client_id = request.args.get('client_id')
    days = int(request.args.get('days', 7))
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    cutoff = datetime.utcnow() - timedelta(days=days)
    
    # Get competitors
    competitors = DBCompetitor.query.filter_by(
        client_id=client_id,
        is_active=True
    ).all()
    
    comp_ids = [c.id for c in competitors]
    comp_names = {c.id: c.name or c.domain for c in competitors}
    
    # Get recently discovered pages
    recent_pages = DBCompetitorPage.query.filter(
        DBCompetitorPage.competitor_id.in_(comp_ids),
        DBCompetitorPage.discovered_at >= cutoff
    ).order_by(DBCompetitorPage.discovered_at.desc()).limit(50).all()
    
    alerts = []
    for page in recent_pages:
        # Extract topic from title
        topic = page.title or page.url.split('/')[-1].replace('-', ' ')
        
        alerts.append({
            'competitor_id': page.competitor_id,
            'competitor_name': comp_names.get(page.competitor_id, 'Unknown'),
            'page_id': page.id,
            'title': page.title,
            'url': page.url,
            'topic': topic,
            'detected_at': page.discovered_at.isoformat() if page.discovered_at else None
        })
    
    return jsonify({
        'alerts': alerts,
        'total': len(alerts),
        'days_checked': days
    })


@monitoring_bp.route('/top-keywords', methods=['GET'])
@token_required
def get_top_keywords(current_user):
    """
    Get top-ranked keywords from SEMrush domain data (not just tracked keywords)
    Returns best-performing keywords sorted by position
    
    GET /api/monitoring/top-keywords?client_id=xxx&limit=10
    """
    client_id = request.args.get('client_id')
    
    if not client_id:
        return jsonify({'error': 'client_id required'}), 400
    
    if not current_user.has_access_to_client(client_id):
        return jsonify({'error': 'Access denied'}), 403
    
    client = DBClient.query.get(client_id)
    if not client:
        return jsonify({'error': 'Client not found'}), 404
    
    limit = min(int(request.args.get('limit', 10)), 50)
    
    try:
        domain = rank_tracking_service._clean_domain(client.website_url or client.business_name)
        database = rank_tracking_service.default_database
        
        # FIRST: Try DB rank history (FREE — no API units)
        from sqlalchemy import func
        subq = db.session.query(
            DBRankHistory.keyword,
            func.max(DBRankHistory.checked_at).label('latest')
        ).filter(
            DBRankHistory.client_id == client_id
        ).group_by(DBRankHistory.keyword).subquery()
        
        latest_ranks = db.session.query(DBRankHistory).join(
            subq,
            db.and_(
                DBRankHistory.keyword == subq.c.keyword,
                DBRankHistory.checked_at == subq.c.latest,
                DBRankHistory.client_id == client_id
            )
        ).all()
        
        if latest_ranks:
            keywords = []
            for r in latest_ranks:
                if r.position and r.position <= 100:
                    keywords.append({
                        'keyword': r.keyword,
                        'position': r.position,
                        'previous_position': r.previous_position,
                        'change': r.change or 0,
                        'url': r.url or '',
                        'search_volume': r.search_volume or 0,
                        'cpc': r.cpc or 0.0
                    })
            keywords.sort(key=lambda x: x['position'])
            return jsonify({
                'keywords': keywords[:limit],
                'total': len(keywords),
                'cached': True,
                'domain': domain
            })
        
        # Only call SEMrush API if no DB data exists
        import requests as http_requests
        api_key = rank_tracking_service.api_key
        
        if not api_key:
            return jsonify({'keywords': [], 'error': 'No cached data and SEMrush API key not configured'}), 200
        
        params = {
            'type': 'domain_organic',
            'key': api_key,
            'display_limit': limit,
            'display_sort': 'po_asc',
            'export_columns': 'Ph,Po,Pp,Nq,Cp,Ur',
            'domain': domain,
            'database': database
        }
        
        response = http_requests.get(rank_tracking_service.base_url, params=params, timeout=30)
        
        if response.text.startswith('ERROR'):
            logger.warning(f"SEMrush top-keywords error: {response.text[:100]}")
            return jsonify({'keywords': [], 'error': response.text[:200]}), 200
        
        if response.status_code != 200:
            return jsonify({'keywords': [], 'error': f'SEMrush API error: {response.status_code}'}), 200
        
        keywords = []
        lines = response.text.strip().split('\n')
        
        if len(lines) > 1:
            for line in lines[1:]:
                parts = line.split(';')
                if len(parts) >= 5:
                    pos = int(parts[1]) if parts[1] else None
                    prev_pos = int(parts[2]) if parts[2] else None
                    
                    if pos and pos > 0:
                        change = (prev_pos - pos) if prev_pos else 0
                        keywords.append({
                            'keyword': parts[0].strip('"'),
                            'position': pos,
                            'previous_position': prev_pos,
                            'change': change,
                            'search_volume': int(parts[3]) if parts[3] else 0,
                            'cpc': float(parts[4]) if parts[4] else 0.0,
                            'url': parts[5].strip('"') if len(parts) > 5 and parts[5] else None
                        })
        
        # Already sorted by position from API, take top N
        top_keywords = keywords[:limit]
        
        return jsonify({
            'domain': domain,
            'keywords': top_keywords,
            'total_ranked': len(keywords)
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500
