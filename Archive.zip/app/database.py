"""
MCP Framework - Database Configuration
SQLAlchemy ORM setup for PostgreSQL
"""
from flask_sqlalchemy import SQLAlchemy
import logging
logger = logging.getLogger(__name__)
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import text
from datetime import datetime


class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)


def run_migrations(app):
    """Run any pending database migrations"""
    with app.app_context():
        try:
            # Check if service_cities column exists in clients table
            result = db.session.execute(text("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'clients' AND column_name = 'service_cities'
            """))
            if not result.fetchone():
                logger.info("Adding service_cities column to clients table...")
                db.session.execute(text("""
                    ALTER TABLE clients 
                    ADD COLUMN service_cities TEXT DEFAULT '[]'
                """))
                db.session.commit()
                logger.info("✓ Added service_cities column")
            
            # Check if blog_url column exists
            result = db.session.execute(text("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'clients' AND column_name = 'blog_url'
            """))
            if not result.fetchone():
                logger.info("Adding blog_url column to clients table...")
                db.session.execute(text("""
                    ALTER TABLE clients 
                    ADD COLUMN blog_url VARCHAR(500)
                """))
                db.session.commit()
                logger.info("✓ Added blog_url column")
            
            # Check if contact_url column exists
            result = db.session.execute(text("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'clients' AND column_name = 'contact_url'
            """))
            if not result.fetchone():
                logger.info("Adding contact_url column to clients table...")
                db.session.execute(text("""
                    ALTER TABLE clients 
                    ADD COLUMN contact_url VARCHAR(500)
                """))
                db.session.commit()
                logger.info("✓ Added contact_url column")
            
            # Check if target_city column exists in blog_posts
            result = db.session.execute(text("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'blog_posts' AND column_name = 'target_city'
            """))
            if not result.fetchone():
                logger.info("Adding target_city column to blog_posts table...")
                db.session.execute(text("""
                    ALTER TABLE blog_posts 
                    ADD COLUMN target_city VARCHAR(100)
                """))
                db.session.commit()
                logger.info("✓ Added target_city column")
            
            # Check if tags column exists in blog_posts
            result = db.session.execute(text("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'blog_posts' AND column_name = 'tags'
            """))
            if not result.fetchone():
                logger.info("Adding missing columns to blog_posts table...")
                db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN tags TEXT DEFAULT '[]'"))
                db.session.commit()
                logger.info("✓ Added tags column")
            
            # Check if revision_notes column exists in blog_posts
            result = db.session.execute(text("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'blog_posts' AND column_name = 'revision_notes'
            """))
            if not result.fetchone():
                logger.info("Adding revision_notes column to blog_posts table...")
                db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN revision_notes TEXT"))
                db.session.commit()
                logger.info("✓ Added revision_notes column")
            
            # Check if approved_at column exists in blog_posts
            result = db.session.execute(text("""
                SELECT column_name FROM information_schema.columns 
                WHERE table_name = 'blog_posts' AND column_name = 'approved_at'
            """))
            if not result.fetchone():
                logger.info("Adding approval columns to blog_posts table...")
                db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN approved_at TIMESTAMP"))
                db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN approved_by VARCHAR(50)"))
                db.session.commit()
                logger.info("✓ Added approval columns")
            
            # Add blog_tasks table if not exists
            db.session.execute(text("""
                CREATE TABLE IF NOT EXISTS blog_tasks (
                    task_id VARCHAR(100) PRIMARY KEY,
                    task_data TEXT,
                    created_at TIMESTAMP DEFAULT NOW(),
                    updated_at TIMESTAMP DEFAULT NOW()
                )
            """))
            db.session.commit()
            
            # Widen meta_title and meta_description columns in blog_posts
            # (PostgreSQL will reject inserts if AI-generated titles exceed old limits)
            try:
                result = db.session.execute(text("""
                    SELECT character_maximum_length FROM information_schema.columns 
                    WHERE table_name = 'blog_posts' AND column_name = 'meta_title'
                """))
                row = result.fetchone()
                if row and row[0] and row[0] < 500:
                    logger.info("Widening meta_title/meta_description columns in blog_posts...")
                    db.session.execute(text("ALTER TABLE blog_posts ALTER COLUMN meta_title TYPE VARCHAR(500)"))
                    db.session.execute(text("ALTER TABLE blog_posts ALTER COLUMN meta_description TYPE VARCHAR(500)"))
                    db.session.commit()
                    logger.info("✓ Widened blog_posts meta columns to 500")
            except Exception as e:
                logger.debug(f"blog_posts meta column check: {e}")
                try:
                    db.session.rollback()
                except:
                    pass
            
            # Same for content_queue table
            try:
                result = db.session.execute(text("""
                    SELECT character_maximum_length FROM information_schema.columns 
                    WHERE table_name = 'content_queue' AND column_name = 'meta_title'
                """))
                row = result.fetchone()
                if row and row[0] and row[0] < 500:
                    logger.info("Widening meta_title/meta_description columns in content_queue...")
                    db.session.execute(text("ALTER TABLE content_queue ALTER COLUMN meta_title TYPE VARCHAR(500)"))
                    db.session.execute(text("ALTER TABLE content_queue ALTER COLUMN meta_description TYPE VARCHAR(500)"))
                    db.session.commit()
                    logger.info("✓ Widened content_queue meta columns to 500")
            except Exception as e:
                logger.debug(f"content_queue meta column check: {e}")
                try:
                    db.session.rollback()
                except:
                    pass
            
            # Same for service_pages table
            try:
                result = db.session.execute(text("""
                    SELECT character_maximum_length FROM information_schema.columns 
                    WHERE table_name = 'service_pages' AND column_name = 'meta_title'
                """))
                row = result.fetchone()
                if row and row[0] and row[0] < 500:
                    logger.info("Widening meta_title/meta_description columns in service_pages...")
                    db.session.execute(text("ALTER TABLE service_pages ALTER COLUMN meta_title TYPE VARCHAR(500)"))
                    db.session.execute(text("ALTER TABLE service_pages ALTER COLUMN meta_description TYPE VARCHAR(500)"))
                    db.session.commit()
                    logger.info("✓ Widened service_pages meta columns to 500")
            except Exception as e:
                logger.debug(f"service_pages meta column check: {e}")
                try:
                    db.session.rollback()
                except:
                    pass
            
            # Check if notification_cc/bcc columns exist in chatbot_configs
            try:
                result = db.session.execute(text("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'chatbot_configs' AND column_name = 'notification_cc'
                """))
                if not result.fetchone():
                    logger.info("Adding notification_cc and notification_bcc columns to chatbot_configs...")
                    db.session.execute(text("ALTER TABLE chatbot_configs ADD COLUMN notification_cc VARCHAR(500)"))
                    db.session.execute(text("ALTER TABLE chatbot_configs ADD COLUMN notification_bcc VARCHAR(500)"))
                    db.session.commit()
                    logger.info("✓ Added notification CC/BCC columns")
            except Exception as e:
                logger.debug(f"notification cc/bcc migration: {e}")
                try:
                    db.session.rollback()
                except:
                    pass
            
            # Check if crawl_hour/crawl_day columns exist in competitors
            try:
                result = db.session.execute(text("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'competitors' AND column_name = 'crawl_hour'
                """))
                if not result.fetchone():
                    logger.info("Adding crawl_hour and crawl_day columns to competitors table...")
                    db.session.execute(text("ALTER TABLE competitors ADD COLUMN crawl_hour INTEGER DEFAULT 3"))
                    db.session.execute(text("ALTER TABLE competitors ADD COLUMN crawl_day INTEGER DEFAULT 0"))
                    db.session.commit()
                    logger.info("✓ Added crawl_hour and crawl_day columns")
            except Exception as e:
                logger.debug(f"crawl columns migration: {e}")
                try:
                    db.session.rollback()
                except:
                    pass
            
            # Check if share_token column exists in chat_conversations
            try:
                result = db.session.execute(text("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'chat_conversations' AND column_name = 'share_token'
                """))
                if not result.fetchone():
                    logger.info("Adding share_token column to chat_conversations table...")
                    db.session.execute(text("ALTER TABLE chat_conversations ADD COLUMN share_token VARCHAR(64)"))
                    db.session.commit()
                    logger.info("✓ Added share_token column")
                    
                    # Backfill existing conversations with share tokens
                    import uuid as _uuid
                    existing = db.session.execute(text(
                        "SELECT id FROM chat_conversations WHERE share_token IS NULL"
                    )).fetchall()
                    for row in existing:
                        token = _uuid.uuid4().hex + _uuid.uuid4().hex[:8]
                        db.session.execute(text(
                            "UPDATE chat_conversations SET share_token = :token WHERE id = :cid"
                        ), {"token": token, "cid": row[0]})
                    db.session.commit()
                    logger.info(f"✓ Backfilled {len(existing)} conversations with share tokens")
            except Exception as e:
                logger.debug(f"share_token migration: {e}")
                try:
                    db.session.rollback()
                except:
                    pass

            # Migration: chatbot trigger behavior and guided flow columns
            try:
                result = db.session.execute(text("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'chatbot_configs' AND column_name = 'trigger_mode'
                """))
                if not result.fetchone():
                    logger.info("Adding chatbot trigger columns...")
                    chatbot_columns = [
                        ("trigger_mode", "VARCHAR(30) DEFAULT 'disabled'"),
                        ("trigger_delay_seconds", "INTEGER DEFAULT 60"),
                        ("trigger_page_views", "INTEGER DEFAULT 2"),
                        ("reopen_after_close", "BOOLEAN DEFAULT FALSE"),
                        ("guided_flow_enabled", "BOOLEAN DEFAULT FALSE"),
                        ("guided_flow_json", "TEXT"),
                    ]
                    for col_name, col_type in chatbot_columns:
                        try:
                            db.session.execute(text(f"ALTER TABLE chatbot_configs ADD COLUMN {col_name} {col_type}"))
                            db.session.commit()
                            logger.info(f"  ✓ Added chatbot column: {col_name}")
                        except Exception as col_err:
                            db.session.rollback()
                            if 'already exists' not in str(col_err).lower():
                                logger.warning(f"  Could not add {col_name}: {col_err}")
            except Exception as e:
                logger.debug(f"chatbot trigger migration: {e}")
                try:
                    db.session.rollback()
                except:
                    pass
            
            # Check if fact_check_report column exists in blog_posts
            try:
                result = db.session.execute(text("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'blog_posts' AND column_name = 'fact_check_report'
                """))
                if not result.fetchone():
                    logger.info("Adding fact-check columns to blog_posts table...")
                    db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN fact_check_report TEXT"))
                    db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN fact_check_score INTEGER"))
                    db.session.commit()
                    logger.info("✓ Added fact_check_report and fact_check_score columns")
            except Exception as e:
                logger.debug(f"fact_check migration: {e}")
                try:
                    db.session.rollback()
                except:
                    pass
            
            # Check if review_token column exists in blog_posts
            try:
                result = db.session.execute(text("""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_name = 'blog_posts' AND column_name = 'review_token'
                """))
                if not result.fetchone():
                    logger.info("Adding client review columns to blog_posts table...")
                    db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN review_token VARCHAR(64)"))
                    db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN client_status VARCHAR(30)"))
                    db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN client_reviewed_at TIMESTAMP"))
                    db.session.execute(text("ALTER TABLE blog_posts ADD COLUMN auto_generated BOOLEAN DEFAULT FALSE"))
                    db.session.commit()
                    logger.info("✓ Added review_token, client_status, client_reviewed_at, auto_generated columns")
            except Exception as e:
                logger.debug(f"review_token migration: {e}")
                try:
                    db.session.rollback()
                except:
                    pass

        except Exception as e:
            logger.warning(f"Migration check: {e}")
            try:
                db.session.rollback()
            except:
                pass


def init_db(app):
    """Initialize database with app"""
    db.init_app(app)
    
    with app.app_context():
        # Import models to register them
        from app.models import db_models  # noqa
        from app.models import schedule_models  # noqa — content_schedules, content_comments
        
        # Create all tables
        db.create_all()
        
        logger.info("✓ Database tables created")
    
    # Run migrations for new columns
    run_migrations(app)


def get_db():
    """Get database session"""
    return db.session
